const mongoose = require('mongoose');

const flightSchema = new mongoose.Schema({
    flightNumber: { type: String, required: true },
    sta: { type: String, required: true },
    std: { type: String, required: true },
});

const Flight = mongoose.model('Flight', flightSchema);

module.exports = Flight;