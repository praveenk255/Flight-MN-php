const express = require('express');
const Flight = require('../models/Flight');
const multer = require('multer');
const path = require('path');
const router = express.Router();

// Display main page
router.get('/', (req, res) => {
    Flight.find({}, (err, flights) => {
        if (err) return console.error(err);
        res.render('index', { flights });
    });
});

// Display manage flights page
router.get('/manageFlights', (req, res) => {
    Flight.find({}, (err, flights) => {
        if (err) return console.error(err);
        res.render('manageFlights', { flights });
    });
});

// Add flight
router.post('/addFlight', (req, res) => {
    const { flightNumber, sta, std } = req.body;
    const newFlight = new Flight({ flightNumber, sta, std });

    newFlight.save((err) => {
        if (err) return console.error(err);
        res.redirect('/manageFlights');
    });
});

// Delete flight
router.get('/deleteFlight/:id', (req, res) => {
    Flight.findByIdAndDelete(req.params.id, (err) => {
        if (err) return console.error(err);
        res.redirect('/manageFlights');
    });
});

// Upload flight data from Excel (for simplicity, we're skipping the actual Excel parsing here)
router.post('/uploadExcel', multer().single('excelFile'), (req, res) => {
    console.log(req.file);  // File info
    res.redirect('/manageFlights');
});

// Fetch flight details by flight number
router.get('/flightDetails/:flightNumber', (req, res) => {
    Flight.findOne({ flightNumber: req.params.flightNumber }, (err, flight) => {
        if (err) return console.error(err);
        res.render('index', { flight });
    });
});

module.exports = router;